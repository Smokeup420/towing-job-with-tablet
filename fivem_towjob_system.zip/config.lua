Config = {}

-- Job Start Location
Config.JobStart = {
    coords = vector3(-205.89, -1161.22, 23.69),
    heading = 180.0,
    label = "Tow HQ"
}

-- Vehicle Yard Dropoff
Config.YardZone = {
    coords = vector3(-191.36, -1162.53, 23.67),
    radius = 3.0
}

-- Towable Car Spawn Points
Config.CarSpawns = {
    vector3(215.32, -800.12, 30.85),
    vector3(-450.75, -338.96, 34.50),
    vector3(1145.23, -785.45, 57.60),
    vector3(-1231.76, -273.54, 37.76)
}

-- Reputation
Config.DefaultReputation = 0

-- Notification Lingo
Config.Lingo = {
    "10-50 Car Crash",
    "10-7 On Scene",
    "10-8 Clear",
    "10-9 Repeat Last",
    "10-97 Arrived"
}

-- Turf Zones
Config.TurfZones = {
    ["vinewood"] = {
        label = "Vinewood Blvd",
        coords = vector3(340.2, 220.8, 104.3),
        radius = 150.0
    },
    ["delperro"] = {
        label = "Del Perro",
        coords = vector3(-1381.5, -586.2, 30.2),
        radius = 150.0
    }
}