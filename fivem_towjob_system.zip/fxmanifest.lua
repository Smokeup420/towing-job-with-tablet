fx_version 'cerulean'
game 'gta5'

description 'Advanced Tow Job - QBCore Framework'
author 'FIVEM (ChatGPT)'
version '1.0.0'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/server.lua'
}

ui_page 'html/ui.html'

files {
    'html/ui.html',
    'html/style.css',
    'html/script.js'
}

dependencies {
    'qb-core',
    'qb-target',
    'okokNotify',
    'ox_inventory'
}